extends Area2D

@export_file("level2.tscn") var target_level: String

func _on_body_entered(body):
	if body is CharacterBody2D:
		if target_level == "level3.tscn":
			return
		get_tree().change_scene_to_file(target_level)
