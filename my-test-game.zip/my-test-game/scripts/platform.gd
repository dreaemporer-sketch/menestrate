extends StaticBody2D

@onready var timer: Timer = $Timer
@onready var sprite: Sprite2D = $Sprite2D

func _ready():
	timer.wait_time = 10.0
	timer.one_shot = true
	
	$Area2D.body_entered.connect(_on_body_entered)
	timer.timeout.connect(_on_timeout)

func _on_body_entered(body):
	if body.is_in_group("player"):
		change_color()
		
		if timer.is_stopped():
			timer.start()

func change_color():
	sprite.modulate = Color(1, 0, 0)

func _on_timeout():
	queue_free()
