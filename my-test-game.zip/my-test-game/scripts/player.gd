extends CharacterBody2D

@export var speed = 290.0
@export var jump_velocity = -400.0
@export var boosted_jump_velocity = 400.0 # Higher jump for after 20 deaths
@export var gravity = 800.0
@export var spawn_position = Vector2(100, 100)
@export var fall_threshold = 1500.0

var death_count = 0 # Tracks how many times they fell

func _physics_process(delta):
	# Check for falling out of bounds
	if global_position.y > fall_threshold:
		respawn()

	# Apply gravity
	if not is_on_floor():
		velocity.y += gravity * delta
	
	# Jump Logic
	if Input.is_action_just_pressed("down") and is_on_floor():
	 	# Check if player has died 20 or more times
		if death_count >= 20:
			velocity.y = boosted_jump_velocity
		else:
			velocity.y = jump_velocity
	
	# Movement (Left/Right)
	# Note: get_axis("negative", "positive") 
	var direction = Input.get_axis("right","left")
	velocity.x = direction * speed
	
	move_and_slide()

func respawn():
	death_count += 1
	global_position = spawn_position
	velocity = Vector2.ZERO
	
	# Optional: Print to console to track progress
	print("Deaths: ", death_count)
	
	if death_count == 20:
		print("Boosted Jump Active!")

func Character_last_mins(body: Node2D) -> void:
	pass 
