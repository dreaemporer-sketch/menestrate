extends Area2D

@onready var sprite: Sprite2D = $"../Sprite2D"

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		change_color()

func change_color() -> void:
	sprite.modulate = Color(1, 0, 0)
